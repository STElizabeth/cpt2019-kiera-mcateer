var counter = 1

function ChangeIt() {

	if (counter === 1) {
		document.searchImage.src = "image1.gif"
		counter ++;
          }
         else if (counter ===2){
document.searchImage.src = "image2.gif"
	counter ++;
}

  	 else if (counter ===3){
document.searchImage.src = "image3.gif"
	counter ++;
}


     else if (counter===6){
document.searchImage.src = "image6.gif"
